SAVANNA BREW CAFE WEBSITE
Course: Introduction to Web Development

FILES
- index.html: Home page
- about.html: About Us page
- menu.html: Menu page
- gallery.html: Gallery page
- contact.html: Contact and reservations page
- css/style.css: Shared external stylesheet
- images/: Image assets used throughout the site

HOW TO RUN
1. Extract the savanna-brew folder.
2. Open index.html in a web browser.
3. Use the navigation menu to visit all five pages.

NOTES
- The website uses HTML5 and external CSS only. No JavaScript or CSS frameworks are used.
- The contact/reservation form performs browser-side required-field validation but does not submit to a real booking service because no backend is included.
- Replace the image placeholders in the images folder with suitable image files using the same filenames.
- Google Fonts are loaded from the internet; fallback fonts are specified in CSS.
- Validate each HTML file with the W3C Markup Validator and css/style.css with the W3C CSS Validator before submission. Record any remaining warnings here.
