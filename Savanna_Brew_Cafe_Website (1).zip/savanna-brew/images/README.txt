The .svg files are original local placeholder illustrations so the website works offline. Replace them with real photographs if required, and update the corresponding HTML/CSS filenames.
